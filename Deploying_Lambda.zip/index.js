/**
Title: Lambda Function to Deploy Zip file code into another Aws Lambda which will be pushed into S3Bucket.
Author: Avinash K
Date: 01-12-2016

*/

// Initializing variables
var AWS = require('aws-sdk');	
var appConfig = require('./data/config.json');
var request = require('request');
var awsLambdaConfig = {};
var lambda = {};
var S3Object = {};

//Event triggered after file pushe into S3Bucket
exports.handler = function (event, context) {
	console.log("Lambda Function Triggered with config Object -  " + JSON.stringify(appConfig));
    console.log(JSON.stringify(event));
    console.log(JSON.stringify(context));		
	//Getting bucket name of the uploaded file
    S3Object.bucket = event.Records[0].s3.bucket.name;
	//Getting key info of the uploaded file
    S3Object.key = event.Records[0].s3.object.key;
	//Getting version info of the uploaded file
	S3Object.version = event.Records[0].s3.object.versionId;
	//Calling function to get lambda function deployment configuration 
	getLambdaConfiguration(S3Object);
};   

//Function to get lambda function deployment configuration
var getLambdaConfiguration = function (S3Object) {
    console.log("S3 Object Config- "+JSON.stringify(S3Object));
	request({
                url: appConfig.configFileUrl,
                json: true,
                method: 'GET'               
            }, function (error, response, body) {
                if (error) {
                    console.log(error);
                } else {
                    console.log("Config File Reterieved Successfully " + JSON.stringify(body));
					//Calling function to deploy zip file code package into aws lambda
					uploadLambdaFunction(body);     
                }
            });
}
	
//Function to deploy code into aws lambda service
var uploadLambdaFunction = function (config) {
	//Initiallising lambda config
	awsLambdaConfig = {
	    accessKeyId: config.accessKeyId,
	    secretAccessKey: config.secretAccessKey,
	    region: config.region
	}
	lambda = new AWS.Lambda(awsLambdaConfig);	
	//If request is for updating existing lambda function
	if(config.lambdaFunctionType=="old"){
		// Calling function to deploy code into existing lambda function
		updateLambdaFunction(config);		
	}
	//else create a new lambda service and upload the code
	else{
		// Calling function to create a new lambda function and deploy code into it
	    createLambdaFunction(config)
	}
}

//Function to create a new Lambda service and to deploy the code
var createLambdaFunction =function(config){
	console.log("Calling createLambdaFunction to create a new lambda function and deploy code into it");
	var params = {
	  Code: { /* required */
		S3Bucket: S3Object.bucket,
		S3Key: S3Object.key,
		S3ObjectVersion: S3Object.version
	  },
	  FunctionName: config.lambdaFunctionName, /* required */
	  Handler: config.lambdaHandler, /* required */
	  Role: config.lambdaRole, /* required */
	  Runtime: config.lambdaRuntime, /* required */
	  Description: config.lambdaDescription,
	  // Environment: {
		// Variables: {
		  // someKey: 'STRING_VALUE',
		  // /* anotherKey: ... */
		// }
	  // },
	  //KMSKeyArn: 'STRING_VALUE',
	  MemorySize: 128,
	  Publish: true,
	  Timeout: 40, /* Max 300 */
	  // VpcConfig: {
		// SecurityGroupIds: [
		  // 'STRING_VALUE',
		  // /* more items */
		// ],
		// SubnetIds: [
		  // 'STRING_VALUE',
		  // /* more items */
		// ]
	  // }
	};
	//calling aws lambda to create a new lambda function and deploy the code into it
	lambda.createFunction(params, function(err, data, lambdaConfig) {
	  if (err) console.log(err, err.stack); // an error occurred
	  else     console.log(data);           // successful response
	});
}

//Function to deploy code into exisiting Lambda service
var updateLambdaFunction = function(config){
	console.log("Calling updateLambdaFunction to update code into Existing Lambda");
	//Forming request parameter
	var params = {
	  FunctionName: config.lambdaFunctionName, /* required */
	  Publish: true,
	  S3Bucket: S3Object.bucket,
	  S3Key: S3Object.key,
	  S3ObjectVersion: S3Object.version
	};
	//calling aws lambda update the lambda function code
	lambda.updateFunctionCode(params, function(err, data) {
	  if (err) console.log("Error " + err, err.stack); // an error occurred
	  else     console.log("Updated Successfully " + JSON.stringify(data));// successful response
	});
}
