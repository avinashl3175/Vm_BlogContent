Configuration and Setup :

1) Create Configuration file config.JSON by keeping relevant property and value.
2) Create Zip file of your Lambda Function code (index.js and node_modules) which you want to deploy into your specified lambda function in config.JSON file.

Deployment:
1) Push config.JSON file into AWS bucket (lambda.deployment).
2) Mark config.JSON file as public.
3) Push <LambdaCode>.zip into AWS bucket (lambda.deployment).

Result : 
1) Based on your configuration your "existing lambda function code will be updated or a new lambda function will be created" mapped with the zip code kept inside AWS S3 bucket.

Sample :

You can find sample code for following:

1) Creating config.JSON file for deployment into existing lambda function (Config_New_Lambda_Deployment).
2) Creating config.JSON file for creating a new lambda function and doing deployment into it (Config_Old_Lambda_Deployment).
3) A sample Lambda function zip code (SampleLambdaZipCode).
4) Complete Lambda Function code for doing deployment of another lambda function(Lambda_Code_Deploying_Another_Lambda).

Links:
1) AWS Lambda Function :
   https://us-west-2.console.aws.amazon.com/lambda/home?region=us-west-2#/functions/lambdaDeployment
   
2) Lambda Function code :
   https://github.com/vmpurplehome/downloads/blob/master/Lambda_Code_Deploying_Another_Lambda.zip